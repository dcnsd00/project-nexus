# NEXUS MASTER — ultimul raport de audit

Versiunea curentă a sursei este **0.10.19**. Raportul complet, cu teste, limitări și starea wallet recovery, este în [`AUDIT_REPORT_0.10.19.md`](AUDIT_REPORT_0.10.19.md).

Changelog: [`CHANGELOG_0.10.19.md`](CHANGELOG_0.10.19.md).
