"""Local desktop interface."""
