"""MULTIMINER X core."""
