"""NEXUS RCSC research starter package."""

__version__ = "0.1.0"
