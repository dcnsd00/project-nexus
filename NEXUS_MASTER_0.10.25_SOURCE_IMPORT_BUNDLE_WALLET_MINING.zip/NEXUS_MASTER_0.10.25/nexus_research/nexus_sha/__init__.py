"""NEXUS research package - SHA-256/512 criptanaliza si optimizare mining."""

__version__ = "1.0.0"

from . import sha256_advanced, sha512_advanced, differential_search
from . import message_modification, sat_smt_solver, benchmark, stats_analysis
