# NEXUS 0.8.0

- Added responsive Romanian local dashboard with six navigation views and five major work domains.
- Added CoinPaprika catalog connector with local 6-hour cache and on-demand refresh.
- Added documented 2Miners endpoints for RVN, KAS and ETC (EU/US/Asia where documented).
- Added pool filtering and config generation for custom and catalog endpoints. No mining process is started by the config API.
- Added Windows PowerShell installer, venv setup and Desktop shortcut.
- Added explicit documentation that catalog coverage is provider-based and pool list is not exhaustive.
