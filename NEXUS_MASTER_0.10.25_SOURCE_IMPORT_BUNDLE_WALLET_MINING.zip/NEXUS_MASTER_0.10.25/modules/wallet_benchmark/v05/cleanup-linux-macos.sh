#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
docker compose down --remove-orphans
